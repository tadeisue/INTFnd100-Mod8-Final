# ------------------------------------------------- #
# Title: Assignment 08
# Description: Working with Classes
# ChangeLog: (Susan Tadei, 6-16-23, Add Code to make Assignment 08 Final Run)
# Susan Tadei, 6-16-23, Created Script
# Susan Tadei, 6-16-23, Add Starter Code from Assignment 06
# Susan Tadei, 6-16-23, Modify Code for Assignment 08
# ------------------------------------------------- #

# Data ----------------------------------#
strFileName = 'products.txt'
lstOfProductObjects = []
lstOfProductRows = []

class Product():
    """Stores data about a product:

    properties:
        product_name: (string) with the products's name
        product_price: (float) with the product's standard price
    methods: to_string() - (str) with all properties
        changeLog: (When, Who, What)
        Susan Tadei, 6-16-23, Modified code to complete Assignment 08
    """
        # -- Constructor --
    def __init__(self, product_name: str, product_price: float):
            # Attribute
        self.product_name = product_name
        self.product_price = product_price

        # -- Properties --
        # -- Product Name--

    @property  # You don't use for the getter's directive!
    def product_name(self):  # (getter or accessor)
        return str(self.__product__name).title()  # Format attribute as Title case

    @product_name.setter  # The @NAME.setter must match the getter's name!
    def product_name(self, value):  # (setter or mutator)
        if str(value).isnumeric() == False:
            self.__product__name = value
        else:
            raise Exception("Names cannot be numbers")

        # -- Product Price --
    @property  # You don't use for the getter's directive!
    def product_price(self):  # (getter or accessor)
        return str(self.__product__price).title()  # Format attribute as Title case

    @product_price.setter  # The @NAME.setter must match the getter's name!
    def product_price(self, value):  # (setter or mutator)
        try:
            self.__product__price = float(value)
        except Exception as e:
            raise Exception("Price must be numbers \"n\t" + e.__str__().title())

        # Methods
    def to_string(self):
        return self.product_name + ',' + str(self.product_price)

    def __str__(self):
        return self.to_string()

    # Data ---------------------------------------#
    # Processing  ------------------------------------------------------------- #
class FileProcessor:
    """Processes data to and from a file and a list of product objects:

    methods:
        save_data_to_file(file_name, list_of_product_objects):

        read_data_from_file(file_name, a list of product objects)

        changelog: (When,Who,What)
            Susan Tadei, 6-16-23, Modified code to complete Assignment 08
        """
    pass

    @staticmethod
    def save_data_to_file(file_name, list_of_product_objects):

        """ Write data to a list of product objects

        :param file_name: (string) with name of file:
        :param list_of_product_objects: (list) of product data saved:
        :return: (bool) with success status
        """
    lstOfProductObjects
    success_status = False
    try:
        file = open(file_name, "w")
        for row in list_of_product_objects:
            file.write(row.to_string() + "\n")
        file.close()
        success_status = True
    except Exception as e:
        raise e
        print("There was a general error!")
        print(e, e.__doc__, type(e), sep='\n')
        #return success_status

    @staticmethod
    def read_file_to_lst_of_product_rows(file_name: str):
        """ Reads data from a file into a list of product rows

        :param file_name: (string) with name of file:
        :return: (list) of product rows
        """
    list_of_product_rows = []
    try:
        file = open(file_name, "r")
        for line in file:
            data = line.split(",")
            row = Product(data[0], data[1])
            list_of_product_rows.append(row)
        file.close()
    except Exception as e:
        raise e
        print("There was a general error!")
        print(e, e.__doc__, type(e), sep='\n')
        return list_of_product_rows


# Processing  --------------------------------------------------------------- #


# Presentation (Input/Output)  -------------------------------------------- #

class IO:
    """ Performs Input and Output tasks """

    @staticmethod
    def OutputMenuChoices():
        """  Display a menu of choices to the user

        :return: nothing
        """
        print('''
        Menu of Options
        1) Add a Product Name
        2) Add a Product Price
        3) Save Data to File        
        4) Exit Program
        ''')
        print()  # Add an extra line for looks

    @staticmethod
    def InputMenuChoice():
        """ Gets the menu choice from a user

        :return: string
        """
        choice = str(input("Which option would you like to perform? [1 to 4] - ")).strip()
        print()  # Add an extra line for looks
        return choice

    @staticmethod
    def output_list_of_product_objects():
        """ Shows the product objects in list of rows

        :param list_of_objects: (list) of product objects you want to display
        :return: nothing
        """
        print("Product Name")
        for row in list_of_product_objects:
            print(row["Product Name"] + " (" + row["Product Price"] + ")")
        print("*******************************************")
        print()  # Add an extra line for looks

    @staticmethod
    def input_product_name_and_product_price():
        """  Gets product name and product price

        :return: (string, string) with product name and product price
        """
pass  # TODO: Add Code Here!

# Main Body of Script  ------------------------------------------------------ #


# Step 1 - When the program starts, Load data from ToDoFile.txt.
#FileProcessor.readFileDataToList(file_name = strFileName, list_of_rows = lstTable)  # read file data

# Step 2 - Display a menu of choices to the user
while (True):
    # Step 3 Show current data
    IO.output_lst_of_product_name(list_of_rows=lstTable)  # Show current data in the list/table
    IO.output_product_price()  # Shows menu
    choice_str = IO.input_menu_choice()  # Get menu option

    # Step 4 - Process user's menu choice
    if choice_str.strip() == '1':  # Add a Product Name
        task, priority = IO.input_product_name()
        lstTable = Processor.add_data_to_list(productname=productname, list_of_rows=lstTable)
        continue  # to show the menu

    elif choice_str == '2':  # Add a Product Price
        task = IO.input_product_price()
        lstTable = Processor.product_price(productprice=productprice, list_of_rows=lstTable)
        continue  # to show the menu

    elif choice_str == '3':  # Save Data to File
        lstTable = Processor.write_data_to_file(file_name = strFileName, list_of_rows=lstTable)
        print("Data Saved!")
        continue  # to show the menu

    elif choice_str == '4':  # Exit Program
        print("Goodbye!")
        break  # by exiting loop




p1 = Product('proda', 9.99)
p2 = Product('prodB', 1.99)
lstOfProductObjects = [p1, p2]
for obj in lstOfProductObjects:
    print(obj.to_string())

FileProcessor.save_data_to_file(strFileName, lstOfProductObjects)



